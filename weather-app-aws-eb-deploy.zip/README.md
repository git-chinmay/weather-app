## weather-app

### A node based rudimentary weather app. Create for learning purpose and not for production use. It uses monthly free subscritptions for fetching weather data. Monthly limit 250 call.

### Created By
Chinmay